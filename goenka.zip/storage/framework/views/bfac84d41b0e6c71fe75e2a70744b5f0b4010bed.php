<!-- Mail Chimp -->
<section class="flat-row mail-chimp">
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <div class="text">
                    <h3>Need more information?</h3>
                    <p>We can call you and help with your problem, just leave us your phone number.</p>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="subscribe">
                    <a href="<?php echo e(route('front.contact')); ?>" class="submit btn btn-md btn-success">Contact Us</a>
                </div>
            </div>
        </div>
    </div><!-- /.container -->
</section>

<!-- Footer -->
<footer class="footer">
    <div class="footer-widgets">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="widget widget_text widget_info">
                        <h4 class="widget-title">About us</h4>
                        <div class="img-container">
                            <a href="<?php echo e(url('/')); ?>">
                                <img style="width: 80px;" src="<?php echo e(asset(getSiteSetting('logo'))); ?>" class="img-fluid" alt="<?php echo e(getSiteSetting('site_title')); ?>" title="<?php echo e(getSiteSetting('site_title')); ?>" />

                            </a>
                        </div>
                        <div class="textwidget">
                            <p>
                                <?php echo e(getSiteSetting('site_Description')); ?>

                            </p>

                        </div><!-- /.textwidget -->
                    </div><!-- /.widget -->
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget">
                        <h2 class="widget-title">Trading Company</h2>
                        <ul>
                            <li><a href="<?php echo e(route('front.unit', 'manufacturing-unit')); ?>">Manufacturing Unit</a></li>
                            <li><a href="<?php echo e(route('front.unit', 'trading-unit')); ?>">Trading Unit</a></li>
                            <li><a href="<?php echo e(route('front.unit', 'other-unit')); ?>">Other Unit</a></li>

                        </ul>
                    </div>
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget">
                        <h2 class="widget-title">Links</h2>
                        <ul>
                            <li><a href="<?php echo e(route('front.product')); ?>">Products</a>
                            </li>
                            <li><a href="<?php echo e(route('front.career')); ?>">Career</a>
                            </li>
                            <li><a href="<?php echo e(route('front.blog')); ?>">Blog</a>
                            <li><a href="<?php echo e(route('front.contact')); ?>">Contact Us</a></li>

                        </ul>
                    </div>
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget widget_text widget_info">
                        <h4 class="widget-title">Contact Us</h4>
                        <div class="textwidget">
                            <ul class="footer-info">
                                <li class="address"> <?php echo e(getSiteSetting('address')); ?></li>
                                <li class="phone"><?php echo e(getSiteSetting('primary_phone')); ?> /<?php echo e(getSiteSetting('secondary_phone')); ?></li>
                                <li class="email"><?php echo e(getSiteSetting('primary_email')); ?></li>
                            </ul>
                        </div><!-- /.textwidget -->
                        <div class="social-links">
                            <a href="<?php echo e(getSiteSetting('youtube_link')??''); ?>"><i class="fa fa-youtube"></i></a>
                            <a href="<?php echo e(getSiteSetting('fb_link')??''); ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo e(getSiteSetting('twitter_link')??''); ?>"><i class="fa fa-twitter"></i></a>
                        </div>
                    </div><!-- /.widget -->
                </div><!-- /.col-md-3 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.footer-widgets -->

</footer>

<!-- Bottom -->
<div class="bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="copyright">
                    <p>© Copyright Goenka 2020. All Rights Reserved.
                    </p>
                </div>
            </div><!-- /.col-md-6 -->
            <div class="col-md-6">
                <div class="copyright ">
                    <p class="text-right">Developed By <a href="https://www.an4soft.com">An4soft</a>
                    </p>
                </div>
            </div><!-- /.col-md-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</div>

<!-- Go Top -->
<a class="go-top">
    <i class="fa fa-angle-up"></i>
</a><?php /**PATH E:\an4softoffice\goenka\resources\views/frontEnd/layout/footer.blade.php ENDPATH**/ ?>
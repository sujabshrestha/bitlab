<?php $__env->startPush('styles'); ?>

    <link href="<?php echo e(asset('cork/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('cork/assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startSection('contents'); ?>



<div class="layout-px-spacing">

    <div class="row layout-top-spacing">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
            <div class="widget widget-chart-one">
                <div class="widget-heading">
                    <h1 class="text-center">Welcome to Admin Panel</h1>

                </div>

                <div class="widget-content">
                    <img style="width: 100%;" src="<?php echo e(asset(getSiteSetting('logo'))); ?>" alt="<?php echo e(getSiteSetting('site_title')??''); ?>">
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script src="<?php echo e(asset('cork/plugins/apex/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cork/assets/js/dashboard/dash_1.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\an4softoffice\goenka\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
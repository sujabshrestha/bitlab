<div class="modal fade" id="messagemodal" role="dialog" style="z-index: 99999">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">
                <section class="flat-row parallax parallax8 row-list chairman-section" id="services">
                    <div class="overlay"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="flat-title color-white"> <span>Chairman</span> Voice</h2>
                                <div class="chairman-name">Chairman: Ram Gopal Goenka</div>
                                <?php echo getSiteSetting('chairman_message'); ?>

                            </div>
                        </div>
                    </div><!-- /.container -->
                </section>
            </div>
        </div>

    </div>
</div><?php /**PATH E:\an4softoffice\goenka\resources\views/frontEnd/pages/postPopup.blade.php ENDPATH**/ ?>
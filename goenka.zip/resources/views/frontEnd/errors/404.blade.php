@extends('frontEnd.layout.master')

@push('script')
@endpush

@section('content')
    <div>
        <h2>Page Not Found.</h2>
    </div>
@endsection

@push('script')
@endpush
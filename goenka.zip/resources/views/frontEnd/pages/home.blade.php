@extends('frontEnd.layout.master')

@push('script')
@endpush

@section('content')


    <!-- Slider -->
    <div class="slider frontslider">
        @if($sliders)
            @foreach($sliders as $slider)
        <div>
            <div class="slider-item">
                <div class="img-container">
                    {!! gobalPostImage($slider->id, 'full', 'img-fluid') !!}
                </div>
                <div class="description">
                    {{ $slider->title }}
                </div>
                <div class="button-container">
                    <a href="{{ route('front.contact') }}">Contact Us</a>
                </div>
            </div>
        </div>
            @endforeach
        @endif
    </div>
    <!-- Offer -->
    <section class="flat-row parallax parallax8 row-list" id="services">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="single-image text-center">
                        <img src="{{ asset(getSiteSetting('about_banner')) }}" alt="ipad">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="empty-space d15px"></div>
                    <h2 class="flat-title color-white">Welcome To <br> <span>Goenka Group</span></h2>
                    <p>
                      {!! getSiteSetting('about')??'' !!}
                    </p>
                </div>
            </div>
        </div><!-- /.container -->
    </section>



    <!-- Products -->
    <section class="flat-row portfolio-style2" id="work">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section style2 style3">
                        <h1 class="title">OUR PRODUCTS</h1>
                    </div>
                </div><!-- /.col-md-12 -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <ul class="portfolio-filter">
                        <li class="active"><a data-filter="*" href="#">All Products</a></li>

                        @if($productCategories)
                            @foreach($productCategories as $category)
                        <li><a data-filter=".{{ $category->id }}" href="#">{{ $category->title }}</a></li>
                            @endforeach
                            @endif
                    </ul><!-- /.project-filter -->
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flat-portfolio v4 style1 grid-3columns">
                        <div class="portfolio-wrap clearfix">

                            @if($products)
                                @foreach($products as $product)
                            <div class="item {{ $product->parent_category }}">
                                <div class="featured-images">
                                    {!! gobalPostImage($product->id, 'thumbnail') !!}
                                    <h3 class="project-title">{{ $product->title }}</h3>
                                    <a class="view-detail" href="{{ route('front.product.single', $product->slug) }}">View More</a>
                                    <div class="overlay">
                                    </div>
                                </div><!-- /.featured-images -->
                            </div>
                                @endforeach
                                @endif
                        </div><!-- /.portfolio-wrap -->
                    </div><!-- /.flat-portfolio -->
                </div>
            </div>
        </div>
    </section>
    <!-- What we offer -->
    <section class="flat-row about background-color" id="about" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section style3">
                        <h1 class="title">WHAT WE OFFER</h1>
                    </div>
                </div><!-- /.col-md-12 -->
            </div>
            <div class="row">
                @if($offers)
                    @foreach($offers as $offer)
                        <div class="col-md-4">
                            <div class="iconbox  left square">
                                <div class="box-header">
                                    <i class="fa fa-pie-chart"></i>
                                    <div class="box-title"><a href="#">{{ $offer->title }}</a></div>
                                </div>
                                <div class="box-content">
                                    {!! $offer->post_content !!}
                                </div>

                            </div><!-- /.iconbox -->
                        </div>
                        @endforeach
                @endif



            </div>
        </div><!-- /.container -->
    </section>
    <!-- Chairman Voice -->
    <section class="flat-row parallax parallax8 row-list chairman-section" id="services">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="single-image text-center">
                        <img src="{{ asset(getSiteSetting('chairman_photo')) }}" alt="Ram Gopal Goenka">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="empty-space d15px"></div>
                    <h2 class="flat-title color-white"> <span>Chairman</span> Voice</h2>
                    <div class="chairman-name">Chairman: Ram Gopal Goenka</div>
                    {!! substr(getSiteSetting('chairman_message'), 0 , 700) !!}
                    <span class="more-link">
                        <a data-toggle="modal" data-target="#messagemodal" href="#" style=" font-size: 18px; font-weight: 700; color: #d91e2d; ">
                            CONTINUE RED </a>
                    </span>
                </div>
            </div>
        </div><!-- /.container -->
    </section>
    @include('frontEnd.pages.postPopup')
    <!-- Blog -->
    <section class="flat-row blog" id="blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-section">
                        <h1 class="title">FROM THE BLOG</h1>
                    </div>
                </div><!-- /.col-md-12 -->
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="blog-shortcode blog-carosuel-wrap">
                        <div class="blog-carosuel">
                            @if($blogs)
                                @foreach($blogs as $blog)
                            <article class="post clearfix">
                                <div class="featured-post">
                                    <div class="overlay"></div>
                                    {!! gobalPostImage($blog->id, 'full') !!}
                                    <ul class="post-comment">
                                        <li class="date">
                                            <span class="day"> {{ $blog->created_at->format('d') }} </span>
                                        </li>
                                        <li class="comment">
                                            {{ $blog->created_at->format('M') }}
                                        </li>
                                    </ul><!-- /.post-comment -->
                                </div><!-- /.feature-post -->
                                <div class="content-post">
                                    <h2 class="title-post"><a href="{{ route('front.blogSingle', $blog->slug) }}">{{ $blog->title }}</a></h2>

                                    <div class="entry-post excerpt">
                                        <p>{!! substr(strip_tags($blog->post_content), 0 , 100) !!}
                                        </p>
                                    </div>
                                </div><!-- /.content-post -->
                            </article>
                                @endforeach
                                @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="flat-row what-we-do offer parallax parallax5 testimonials-home2" id="services">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flat-testimonials" data-item="1" data-nav="true" data-dots="false" data-auto="false">

                        @if($testimonials )
                        @foreach($testimonials as $testimonial)
                        <div class="testimonials style2">
                            <div class="message">
                                <blockquote class="whisper">{!! substr(strip_tags($testimonial->post_content), 0 , 300) !!}
                                </blockquote>
                                <div class="name"><span>{{ $testimonial->title }}</span></div>
                                <div class="position">{{ $testimonial->degination }}</div>
                            </div>
                        </div>
                            @endforeach
                        @endif

                    </div><!-- /.flat-testimonials-->
                </div>
            </div>
        </div><!-- /.container -->
    </section>
    <!-- Testimonial -->
    <section class="flat-row" id="testimonials">
        <div class="container">



            <div class="title-section">
                <h1 class="title">OUR TEAM </h1>
            </div>
            <div class="wrap-team">
                <div class="flat-team-olw" data-item="3" data-nav="false" data-dots="false" data-auto="false">
                    @if($teams )
                        @foreach($teams as $team)
                    <div class="flat-team style2">
                        <div class="avatar">
                            <div class="overlay">
                            </div>
                            {!! gobalPostImage($team->id, 'thumbnail') !!}
                        </div>
                        <div class="content">
                            <h3 class="name">{{ $team->title }}</h3>
                            <p class="position">{!! $team->post_content !!}</p>
                        </div>
                    </div>
                        @endforeach
                        @endif
                </div>
            </div>

        </div><!-- /.container -->
    </section>

@endsection

@push('script')


<script>
    $('.frontslider').slick({
        dots: false,
        infinite: true,
        speed: 500,
        fade: true,
        autoplay: true,
        cssEase: 'linear',
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 1,
                    dots: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '40px',
                    slidesToShow: 1,
                    dots: true
                }
            }
        ]
    });
</script>

@endpush
@extends('frontEnd.layout.master')
@section('pageTitle', 'Blogs | '.getSiteSetting('site_title'))
@section('pageName', 'Blogs')
@push('style')
@endpush

@section('content')

    <!-- Page title -->
    @include('frontEnd.layout.page-title')
    <!-- /.page-title -->

    <section class="main-content blog-posts">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="post-wrap">
                       <div class="row">
                           @if($posts)
                               @foreach($posts as $post)
                                   <div class="col-md-6">
                                       <article class="  post clearfix">
                                           <div class="featured-post">
                                               {!! gobalPostImage($post->id, 'full') !!}
                                               <ul class="post-comment">
                                                   <li class="date">
                                                       <span class="day"> {{ $post->created_at->format('d') }} </span>
                                                   </li>
                                                   <li class="comment">
                                                       {{ $post->created_at->format('F') }}
                                                   </li>
                                               </ul><!-- /.post-comment -->
                                           </div><!-- /.feature-post -->
                                           <div class="content-post">
                                               <h2 class="title-post"><a href="{{ route('front.blogSingle', $post->slug) }}"> {{ $post->title }}</a></h2>

                                               <div class="entry-post excerpt">
                                                   <p>{!! substr(strip_tags($post->post_content), 0 , 200) !!}
                                                       <span class="more-link"><a href="{{ route('front.blogSingle', $post->slug) }}">CONTINUE RED </a></span></p>
                                               </div>
                                           </div><!-- /.content-post -->
                                       </article>
                                   </div>

                               @endforeach
                           @endif
                       </div>
                    </div><!-- /.post-wrap -->
                    <div class="blog-pagination">
                        {{ $posts->links() }}
                    </div><!-- /.blog-pagination -->
                </div><!-- /.col-md-9 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

@endsection

@push('script')


@endpush
@extends('frontEnd.layout.master')
@section('pageTitle', 'Contact Us | '.getSiteSetting('site_title'))
@section('pageName', 'Contact Us')
@push('style')
@endpush

@section('content')

    <!-- Page title -->
    @include('frontEnd.layout.page-title')
    <!-- /.page-title -->

    <!-- Contact -->
    <section class="flat-row contact-page">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <form class="flat-contact-form style2 bg-dark height-small"  method="post" action="{{ route('front.submitContact') }}">
                        {{ csrf_field() }}
                        <div class="field clearfix">
                            <div class="wrap-type-input">
                                <div class="input-wrap name">
                                    <input type="text" value="" tabindex="1" placeholder="Name" name="name" id="name" required>
                                </div>
                                <div class="input-wrap email">
                                    <input type="email" value="" tabindex="2" placeholder="Email" name="email" id="email" required>
                                </div>
                            </div>
                            <div class="wrap-type-input">
                                <div class="input-wrap name">
                                    <input type="text" value="" tabindex="1" placeholder="Phone" name="phone" id="phone" required>
                                </div>
                                <div class="input-wrap email">
                                    <input type="text" value="" tabindex="2" placeholder="Subject" name="subject" id="subject" required>
                                </div>
                            </div>
                            <div class="textarea-wrap">
                                <textarea class="type-input" tabindex="3" placeholder="Message" name="message" id="message-contact" required></textarea>
                            </div>
                        </div>
                        <div class="submit-wrap">
                            <button class="flat-button bg-theme">Send Your Message</button>
                        </div>
                    </form><!-- /.comment-form -->
                </div><!-- /.col-md-8 -->

                <div class="col-md-4">
                    <h4 class="title-contact-info">CONTACT INFO:</h4>
                    <ul class="flat-contact-info">
                        <li class="address">
                            <i class="fa fa-home"></i> {{ getSiteSetting('address') }}
                        </li>
                        <li class="phone">
                            <i class="fa fa-phone-square"></i> {{ getSiteSetting('primary_phone') }} /{{ getSiteSetting('secondary_phone') }}
                        </li>
                        <li class="email">
                            <i class="fa fa-envelope"></i> {{ getSiteSetting('primary_email') }}
                        </li>
                    </ul><!-- /.contact-infomation -->
                </div><!-- /.col-md-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

    <!-- Map -->
    <div class="flat-row map">
        {!! getSiteSetting('map_location')??'' !!}
    </div><!-- /.flat-row -->

@endsection

@push('script')


@endpush
@extends('frontEnd.layout.master')
@section('pageTitle', 'About Us | '.getSiteSetting('site_title'))
@section('pageName', 'About Us')
@push('style')
@endpush

@section('content')

    <!-- Page title -->
    @include('frontEnd.layout.page-title')
    <!-- /.page-title -->

    <!-- About -->
    <section class="main-content page-single page-about">
        <div class="container">
            <div class="row">
                <div class="page-content">
                    <div class="tab-content">
                        @if($abouts)
                            @foreach($abouts as $about)
                        <div class="tab-pane  {{ $loop->iteration==1?'active':'' }}" id="{{ $about->slug }}">
                            <div class="post-wrap">

                                <div class="about-content-text">
                                   {!! $about->post_content !!}
                                </div>


                            </div>
                        </div>
                            @endforeach
                        @endif
                    </div>

                </div>

                <div class="page-sidebar">
                    <div class="sidebar">
                        <div class="sidebar-nav">
                            <ul>
                                @if($abouts)
                                    @foreach($abouts as $about)
                                <li><a data-toggle="tab" href="#{{ $about->slug }}" class="{{ $loop->iteration==1?'active':'' }}">{{ $about->title }}</a></li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>



                    </div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>

@endsection

@push('script')


@endpush


    <div class="top">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="flat-information">
                        <li class="phone"><a href="{{ getSiteSetting('primary_phone') }}">Call Us: {{ getSiteSetting('primary_phone') }}</a></li>
                        <li class="email"><a href="mailto:{{ getSiteSetting('primary_email') }}">Email Us: {{ getSiteSetting('primary_email') }}</a></li>

                    </ul>
                </div><!-- /.col-md-6 -->
                <div class="col-md-6 d-md-block  d-none">
                    <div class="social-links">
                        <a href="{{ getSiteSetting('youtube_link')??'' }}"><i class="fa fa-youtube"></i></a>
                        <a href="{{ getSiteSetting('fb_link')??'' }}"><i class="fa fa-facebook"></i></a>
                        <a href="{{ getSiteSetting('twitter_link')??'' }}"><i class="fa fa-twitter"></i></a>
                    </div>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.top -->

    <!-- Header -->
    <header id="header" class="header clearfix">
        <div class="container">
            <div class="row">
                <div class="header-wrap clearfix">
                    <div class="col-md-4">
                        <div id="logo" class="logo">
                            <a href="{{ url('/') }}">
                                <img src="{{ asset(getSiteSetting('logo')) }}" class="img-fluid" alt="{{ getSiteSetting('site_title') }}" title="{{ getSiteSetting('site_title') }}" />

                            </a>
                        </div><!-- /.logo -->

                    </div>
                    <div class="col-md-8 pos-static">
                        <div class="nav-wrap has-megamenu">
                            <nav id="mainnav" class="mainnav">
                                <ul class="menu">
                                    <li class="home">
                                        <a href="{{ url('/') }}">Home</a>

                                    </li>
                                    <li><a href="{{ route('front.about-us') }}">About</a></li>

                                    <li><a href="">Company <i class="fa fa-caret-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="{{ route('front.unit', 'manufacturing-unit') }}">Manufacturing Unit</a></li>
                                            <li><a href="{{ route('front.unit', 'trading-unit') }}">Trading Unit</a></li>
                                            <li><a href="{{ route('front.unit', 'other-unit') }}">Other Unit</a></li>


                                        </ul><!-- /.submenu -->
                                    </li>
                                    <li><a href="{{ route('front.product') }}">Products</a>
                                    </li>
                                    <li><a href="{{ route('front.career') }}">Career</a>
                                    </li>
                                    <li><a href="{{ route('front.blog') }}">Blog</a>
                                    <li><a href="{{ route('front.contact') }}">Contact Us</a></li>

                                    </li>

                                </ul><!-- /.menu -->
                            </nav><!-- /.mainnav -->
                            <ul class="menu menu-extra">
                                <li class="off-canvas-toggle">
                                    <a href="#"><i class="fa fa-bars"></i></a>
                                </li>
                            </ul>
                        </div><!-- /.nav-wrap -->


                    </div>
                </div><!-- /.header-inner -->
            </div><!-- /.row -->
        </div>
    </header><!-- /.header -->

    <div id="site-off-canvas">
        <span class="close"></span>
        <div class="wrapper">




            <div id="nav_menu-2" class="widget widget-categories">
                <h4 class="widget-title"></h4>
                <ul class="menu">
                    <li class="home">
                        <a href="index.html">Home</a>

                    </li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="services.html">Company</a></li>
                    <li><a href="work.html">Products</a>
                    </li>
                    <li><a href="manufacture.html">Manufacturing</a></li>
                    <li><a href="blog.html">Blog</a>
                    <li><a href="contact.html">Contact Us</a></li>

                    </li>

                </ul><!-- /.menu -->

            </div>
        </div>
    </div>
    <div class="clearfix"></div>
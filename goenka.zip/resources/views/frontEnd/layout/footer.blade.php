<!-- Mail Chimp -->
<section class="flat-row mail-chimp">
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <div class="text">
                    <h3>Need more information?</h3>
                    <p>We can call you and help with your problem, just leave us your phone number.</p>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="subscribe">
                    <a href="{{ route('front.contact') }}" class="submit btn btn-md btn-success">Contact Us</a>
                </div>
            </div>
        </div>
    </div><!-- /.container -->
</section>

<!-- Footer -->
<footer class="footer">
    <div class="footer-widgets">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="widget widget_text widget_info">
                        <h4 class="widget-title">About us</h4>
                        <div class="img-container">
                            <a href="{{ url('/') }}">
                                <img style="width: 80px;" src="{{ asset(getSiteSetting('logo')) }}" class="img-fluid" alt="{{ getSiteSetting('site_title') }}" title="{{ getSiteSetting('site_title') }}" />

                            </a>
                        </div>
                        <div class="textwidget">
                            <p>
                                {{ getSiteSetting('site_Description') }}
                            </p>

                        </div><!-- /.textwidget -->
                    </div><!-- /.widget -->
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget">
                        <h2 class="widget-title">Trading Company</h2>
                        <ul>
                            <li><a href="{{ route('front.unit', 'manufacturing-unit') }}">Manufacturing Unit</a></li>
                            <li><a href="{{ route('front.unit', 'trading-unit') }}">Trading Unit</a></li>
                            <li><a href="{{ route('front.unit', 'other-unit') }}">Other Unit</a></li>

                        </ul>
                    </div>
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget">
                        <h2 class="widget-title">Links</h2>
                        <ul>
                            <li><a href="{{ route('front.product') }}">Products</a>
                            </li>
                            <li><a href="{{ route('front.career') }}">Career</a>
                            </li>
                            <li><a href="{{ route('front.blog') }}">Blog</a>
                            <li><a href="{{ route('front.contact') }}">Contact Us</a></li>

                        </ul>
                    </div>
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="widget widget_text widget_info">
                        <h4 class="widget-title">Contact Us</h4>
                        <div class="textwidget">
                            <ul class="footer-info">
                                <li class="address"> {{ getSiteSetting('address') }}</li>
                                <li class="phone">{{ getSiteSetting('primary_phone') }} /{{ getSiteSetting('secondary_phone') }}</li>
                                <li class="email">{{ getSiteSetting('primary_email') }}</li>
                            </ul>
                        </div><!-- /.textwidget -->
                        <div class="social-links">
                            <a href="{{ getSiteSetting('youtube_link')??'' }}"><i class="fa fa-youtube"></i></a>
                            <a href="{{ getSiteSetting('fb_link')??'' }}"><i class="fa fa-facebook"></i></a>
                            <a href="{{ getSiteSetting('twitter_link')??'' }}"><i class="fa fa-twitter"></i></a>
                        </div>
                    </div><!-- /.widget -->
                </div><!-- /.col-md-3 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.footer-widgets -->

</footer>

<!-- Bottom -->
<div class="bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="copyright">
                    <p>© Copyright Goenka 2020. All Rights Reserved.
                    </p>
                </div>
            </div><!-- /.col-md-6 -->
            <div class="col-md-6">
                <div class="copyright ">
                    <p class="text-right">Developed By <a href="https://www.an4soft.com">An4soft</a>
                    </p>
                </div>
            </div><!-- /.col-md-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</div>

<!-- Go Top -->
<a class="go-top">
    <i class="fa fa-angle-up"></i>
</a>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>
        @hasSection('pageTitle')
            @yield('pageTitle')
        @else
            {{ getSiteSetting('site_title') }} | {{ getSiteSetting('site_Description') }}
        @endif
    </title>
    @hasSection('metaDescription')
        <meta name="description" content="@yield('metaDescription')">
    @else
        <meta name="description" content="{{ getSiteSetting('site_title') }} | {{ getSiteSetting('site_Description') }}">

    @endif

    @hasSection('metaKeywords')
        <meta name="keywords" content="@yield('metaKeywords')">
    @else
        <meta name="keywords" content="{{ getSiteSetting('site_title') }} | {{ getSiteSetting('site_Description') }}">
    @endif
    <link rel="icon" href="{{ asset(getSiteSetting('favicon')) }}" type="image/gif" sizes="16x16">


    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/stylesheets/bootstrap.css') }}" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/stylesheets/style.css') }}">

    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/stylesheets/responsive.css') }}">

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/stylesheets/colors/color1.css') }}" id="colors">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('front/assets/stylesheets/animate.css') }}">

    <!-- Favicon and touch icons  -->
    <link href="{{ asset(getSiteSetting('favicon')) }}" rel="apple-touch-icon-precomposed">
    <link href="{{ asset(getSiteSetting('favicon')) }}" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
    <script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5a1baeccc87cd900112f804e&product=inline-share-buttons"></script>

    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v9.0&appId=361197191075825&autoLogAppEvents=1" nonce="3B2EeTyk"></script>
    @stack('style')
</head>
<body class="header_sticky">

<div class="boxed">
    @include('frontEnd.layout.header')

    @yield('content')

    @include('frontEnd.layout.footer')



</div>
    <!-- Javascript -->
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.easing.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/imagesloaded.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.isotope.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery-waypoints.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.magnific-popup.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.cookie.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.fitvids.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/parallax.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/smoothscroll.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.flexslider-min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/owl.carousel.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery-validate.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/https://maps.googleapis.com/maps/api/js?sensor=false') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/gmap3.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/main.js') }}"></script>

    <!-- Revolution Slider -->
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.themepunch.tools.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/jquery.themepunch.revolution.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('front/assets/javascript/slider.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
{!! Toastr::message() !!}
@stack('script')
</body>
</html>